﻿namespace AngleFrameworkTest
{
    using AngleFramework;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using System;

    /// <summary>
    /// Defines the <see cref="AngleClassTest" />
    /// </summary>
    [TestClass]
    public class AngleClassTest
    {
        /// <summary>
        /// The PlusOperatorforRadian
        /// </summary>
        [TestMethod]
        public void PlusOperatorforRadian()
        {
            Radian r1 = new Radian { Value = 10 };
            Radian r2 = new Radian { Value = 20 };
            var r3 = r1 + r2;
            var r4 = r3 is Radian ? r3 as Radian : null;
            Assert.AreEqual(30, r4.Radians);
        }

        /// <summary>
        /// The PlusOperatorforDegree
        /// </summary>
        [TestMethod]
        public void PlusOperatorforDegree()
        {
            Degree r1 = new Degree { Value = 10 };
            Degree r2 = new Degree { Value = 20 };
            var r3 = r1 + r2;
            var r4 = r3 is Degree ? r3 as Degree : null;
            Assert.AreEqual(30, r4.Degrees);
        }

      
        /// <summary>
        /// The MixRadianWithDegree
        /// </summary>
        [TestMethod]
        public void MixRadianWithDegree()
        {
            Degree d1 = new Degree { Value = 90 };
            Radian r1 = new Radian { Value = 5 };
            var s1 = r1 + d1;
            var result = s1 as Radian;
            Assert.AreEqual(6.57, Math.Round(result.Radians, 2));
        }

        /// <summary>
        /// The MixDegreeWithRadian
        /// </summary>
        [TestMethod]
        public void MixDegreeWithRadian()
        {
            Radian r1 = new Radian { Value = 5 };
            Degree d1 = new Degree { Value = 90 };
            var s1 = d1 + r1;
            var result = s1 as Degree;
            Assert.AreEqual(376.48, Math.Round(result.Degrees, 2));
        }

        /// <summary>
        /// The IsRadian
        /// </summary>
        [TestMethod]
        public void IsRadian()
        {
            Radian r1 = new Radian { Value = 10 };
            Radian r2 = new Radian { Value = 20 };
            var r3 = r1 + r2;
            var r4 = r3 is Radian ? r3 as Radian : null;
            Assert.AreEqual(typeof(Radian), r4.GetType());
        }

        /// <summary>
        /// The IsDegree
        /// </summary>
        [TestMethod]
        public void IsDegree()
        {
            Degree r1 = new Degree { Value = 10 };
            Degree r2 = new Degree { Value = 20 };
            var r3 = r1 + r2;
            var r4 = r3 is Degree ? r3 as Degree : null;
            Assert.AreEqual(typeof(Degree), r3.GetType());
        }

    }
}
