﻿namespace AngleFrameworkTest
{
    using AngleFramework;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using System;

    /// <summary>
    /// Defines the <see cref="AngleHelperTest" />
    /// </summary>
    [TestClass]
    public class AngleHelperTest
    {
        /// <summary>
        /// The ToRadian
        /// </summary>
        [TestMethod]
        public void ToRadian()
        {
            var result = AngleHelpers.ToRadians(90);
            Assert.AreEqual(1.57, Math.Round(result, 2));
        }

        /// <summary>
        /// The ToDegree
        /// </summary>
        [TestMethod]
        public void ToDegree()
        {
            var result = AngleHelpers.ToDegrees(2);
            Assert.AreEqual(114.59, Math.Round(result, 2));
        }
    }
}
