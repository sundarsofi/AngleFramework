﻿namespace TestApplication
{
    using AngleFramework;
    using System;

    /// <summary>
    /// Defines the <see cref="Program" />
    /// </summary>
    internal class Program
    {
        /// <summary>
        /// The Main
        /// </summary>
        /// <param name="args">The args<see cref="string[]"/></param>
        internal static void Main(string[] args)
        {

            Radian r1 = new Radian { Value = 10 };
            Radian r2 = new Radian { Value = 20 };

            var r3 = r1 + r2;

            Radian r4 = r3 is Radian ? (r3 as Radian) : null;
            Console.WriteLine(r4?.Radians);

            Console.ReadLine();
        }
    }
}
