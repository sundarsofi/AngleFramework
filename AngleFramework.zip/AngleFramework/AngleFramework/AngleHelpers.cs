﻿namespace AngleFramework
{
    using System;

    /// <summary>
    /// Defines the <see cref="AngleHelpers" />
    /// </summary>
    public static class AngleHelpers
    {
        /// <summary>
        /// Presets for quick setup of Angle constructor
        /// </summary>
        private const double twoPi = 2 * Math.PI;

        /// <summary>
        /// Defines the Pi
        /// </summary>
        private const double Pi = Math.PI;

        /// <summary>
        /// Convert an input angle of degrees to radians. Does not affect any properties in this class - set properties instead.
        /// </summary>
        /// <param name="value">Input in degrees</param>
        /// <returns>Value in radians</returns>
        public static double ToRadians(double value)
        {
            return value / (180 / Pi);
        }

        /// <summary>
        /// Convert an input angle of radians into degrees. Does not affect any properties in this class - set properties instead.
        /// </summary>
        /// <param name="value">Input in radians</param>
        /// <returns>Value in degrees</returns>
        public static double ToDegrees(double value)
        {
            return value * (180 / Pi);
        }
    }
}
