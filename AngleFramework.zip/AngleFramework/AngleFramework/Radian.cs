﻿namespace AngleFramework
{
    /// <summary>
    /// Defines the <see cref="Radian" />
    /// </summary>
    public class Radian : Angle
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Radian"/> class.
        /// </summary>
        public Radian()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Radian"/> class.
        /// </summary>
        /// <param name="a1">The a1<see cref="Radian"/></param>
        /// <param name="a2">The a2<see cref="Radian"/></param>
        public Radian(Radian a1, Radian a2)
        {
            Value = a1.Radians + a2.Radians;
        }

        /// <summary>
        /// Defines the radians
        /// </summary>
        private double radians;

        /// <summary>
        /// Gets the Radians
        /// Gets or sets the Radians
        /// Angle in radians between -pi to pi
        /// </summary>
        public double Radians
        {
            get { return radians; }
            private set
            {
                radians = value;
            }
        }

        /// <summary>
        /// The Value
        /// </summary>
        /// <param name="value">The value<see cref="double"/></param>
        protected internal override void setValue(double value)
        {
            Radians = value;
        }

        /// <summary>
        /// The PlusOperator
        /// </summary>
        /// <param name="a1"></param>
        /// <param name="a2"></param>
        /// <returns></returns>
        protected internal override Angle PlusOperator(Angle a1, Angle a2)
        {
            if (!(a2 is Radian))
            {
                Radian r1 = new Radian();
                r1.Value = AngleHelpers.ToRadians(a2.Value);
                return new Radian(a1 as Radian, r1);
            }
            return new Radian(a1 as Radian, a2 as Radian);
        }
    }
}
