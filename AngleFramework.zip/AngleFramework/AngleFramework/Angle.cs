﻿namespace AngleFramework
{
    /// <summary>
    /// Defines the <see cref="Angle" />
    /// </summary>
    public abstract class Angle
    {
        /// <summary>
        /// The PlusOperator
        /// </summary> 
        /// <param name="a1">The a1<see cref="Angle"/></param>
        /// <param name="a2">The a2<see cref="Angle"/></param>
        /// <returns>The <see cref="Angle"/></returns>
        protected internal abstract Angle PlusOperator(Angle a1, Angle a2);

        /// <summary>
        /// The setValue
        /// </summary>
        /// <param name="value">The value<see cref="double"/></param>
        protected internal abstract void setValue(double value);

        /// <summary>
        /// Defines the _value
        /// </summary>
        private double _value;

        /// <summary>
        /// Gets or sets the Value
        /// </summary>
        public double Value
        {
            get { return _value; }
            set
            {
                _value = value;
                setValue(value);
            }
        }

        /// <summary>
        /// Returns the sum of two angles
        /// </summary>
        /// <param name="a1">First angle</param>
        /// <param name="a2">Second angle</param>
        /// <returns>An angle constructed from the radian sum of the input angles</returns>
        public static Angle operator +(Angle a1, Angle a2)
        {
            return a1.PlusOperator(a1, a2);
        }
    }
}