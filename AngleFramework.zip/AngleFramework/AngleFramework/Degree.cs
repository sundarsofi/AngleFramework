﻿namespace AngleFramework
{
    /// <summary>
    /// Defines the <see cref="Degree" />
    /// </summary>
    public class Degree : Angle
    {
        /// <summary>
        /// Defines the _degree
        /// </summary>
        private double _degree;

        /// <summary>
        /// Gets the Degrees
        /// Gets or sets the Degrees
        /// </summary>
        public double Degrees
        {
            get { return _degree; }
            private set { _degree = value; }
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Degree"/> class.
        /// </summary>
        public Degree()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Degree"/> class.
        /// </summary>
        /// <param name="d1">The d1<see cref="Degree"/></param>
        /// <param name="d2">The d2<see cref="Degree"/></param>
        public Degree(Degree d1, Degree d2)
        {
            Value = d1.Degrees + d2.Degrees;
        }

        /// <summary>
        /// The Value
        /// </summary>
        /// <param name="value">The value<see cref="double"/></param>
        protected internal override void setValue(double value)
        {
            Degrees = value;
        }

        /// <summary>
        /// The PlusOperator
        /// </summary>
        /// <param name="a1">The a1<see cref="Angle"/></param>
        /// <param name="a2">The a2<see cref="Angle"/></param>
        /// <returns>The <see cref="Angle"/></returns>
        protected internal override Angle PlusOperator(Angle a1, Angle a2)
        {

            if (!(a2 is Degree))
            {
                Degree d1 = new Degree();
                d1.Value = AngleHelpers.ToDegrees((a2 as Radian).Radians);
                return new Degree(a1 as Degree, d1);
            }
            return new Degree(a1 as Degree, a2 as Degree);
        }
    }
}
